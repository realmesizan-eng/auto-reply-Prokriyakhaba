package com.autoreply.pilot

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class Pending(val text: String, val time: Long)

class AutoTypeService : AccessibilityService() {

    companion object {
        @Volatile var pending: Pending? = null
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val p = pending ?: return
        if (System.currentTimeMillis() - p.time > 20_000) { pending = null; return }
        if (e?.packageName?.toString() !in NotifListener.TIKTOK) return

        val root = rootInActiveWindow ?: return
        val input = findEditable(root) ?: return
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, p.text)
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return
        pending = null

        Handler(Looper.getMainLooper()).postDelayed({
            rootInActiveWindow?.let { clickSend(it) }
        }, 1200)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    private fun clickSend(root: AccessibilityNodeInfo) {
        // টিকটকের আপডেটে বাটনের নাম বদলালে এখানে নতুন নাম যোগ করুন
        val labels = listOf("Send", "send", "পাঠান")
        for (l in labels) {
            for (node in root.findAccessibilityNodeInfosByText(l)) {
                var x: AccessibilityNodeInfo? = node
                while (x != null && !x.isClickable) x = x.parent
                if (x != null && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            }
        }
    }

    override fun onInterrupt() {}
}
