package com.autoreply.pilot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Chat(val name: String, val inMsg: String, val outMsg: String, val time: Long)

object Store {
    const val DEF_PRODUCTS = "হানি নাট|650|৫০০ গ্রাম\nমিক্স ড্রাই ফ্রুটস|900|৫০০ গ্রাম"
    const val DEF_RULES = """ডেলিভারি,কত দিন,কয়দিন,আসতে=>অর্ডার কনফার্ম করার পর সাধারণত ২ থেকে ৪ কার্যদিবসের মধ্যে পার্সেল আপনার ঠিকানায় পৌঁছে দেওয়া হয়। আপনি কি অর্ডার করতে চান?
কোয়ালিটি,ভালো,মান,quality=>আমাদের প্রোডাক্ট ১০০% খাঁটি ও প্রিমিয়াম কোয়ালিটির। ডেলিভারির সময় পার্সেল খুলে চেক করে নিতে পারবেন।
অর্ডার,কিনব,নিব,order=>অর্ডার করতে আপনার নাম, ফোন নম্বর ও পূর্ণ ঠিকানা পাঠান। আমরা দ্রুত কনফার্ম করব।
*=>ধন্যবাদ আপনার মেসেজের জন্য! আমাদের প্রতিনিধি শীঘ্রই আপনাকে বিস্তারিত জানাবে।"""

    private fun sp(c: Context) = c.getSharedPreferences("pilot", Context.MODE_PRIVATE)

    fun active(c: Context) = sp(c).getBoolean("active", true)
    fun setActive(c: Context, v: Boolean) = sp(c).edit().putBoolean("active", v).apply()

    fun products(c: Context) = sp(c).getString("products", DEF_PRODUCTS)!!
    fun setProducts(c: Context, v: String) = sp(c).edit().putString("products", v).apply()

    fun rules(c: Context) = sp(c).getString("rules", DEF_RULES)!!
    fun setRules(c: Context, v: String) = sp(c).edit().putString("rules", v).apply()

    fun blocked(c: Context): Set<String> = sp(c).getStringSet("blocked", emptySet())!!.toSet()
    fun toggleBlocked(c: Context, name: String) {
        val s = blocked(c).toMutableSet()
        if (!s.add(name)) s.remove(name)
        sp(c).edit().putStringSet("blocked", s).apply()
    }

    @Synchronized
    fun chats(c: Context): List<Chat> {
        val arr = JSONArray(sp(c).getString("chats", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Chat(o.getString("n"), o.getString("i"), o.getString("o"), o.getLong("t"))
        }
    }

    @Synchronized
    fun addChat(c: Context, chat: Chat) {
        val list = (listOf(chat) + chats(c)).take(200)
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("n", it.name).put("i", it.inMsg).put("o", it.outMsg).put("t", it.time))
        }
        sp(c).edit().putString("chats", arr.toString()).apply()
    }

    fun clearChats(c: Context) = sp(c).edit().putString("chats", "[]").apply()
}
