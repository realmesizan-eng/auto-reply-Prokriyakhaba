package com.autoreply.pilot

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlin.random.Random

class NotifListener : NotificationListenerService() {

    companion object {
        val TIKTOK = setOf(
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill",
            "com.ss.android.ugc.aweme"
        )
        private val seen = HashMap<String, Long>()
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in TIKTOK) return
        if (!Store.active(this)) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        val ex = n.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
        if (title.isBlank() || text.isBlank()) return
        if (title in Store.blocked(this)) return

        val now = System.currentTimeMillis()
        synchronized(seen) {
            val key = "$title|$text"
            val t = seen[key]
            if (t != null && now - t < 120_000) return
            seen[key] = now
        }

        val reply = ReplyEngine.reply(this, text)
        if (reply.isBlank()) return

        // মানুষের মতো ২-৫ সেকেন্ড দেরিতে উত্তর
        val delay = Random.nextLong(2000, 5000)
        handler.postDelayed({ send(n, title, text, reply) }, delay)
    }

    private fun send(n: Notification, title: String, text: String, reply: String) {
        var sent = false
        val action = n.actions?.firstOrNull { it.remoteInputs?.isNotEmpty() == true }
        if (action != null) {
            // পদ্ধতি ১: নোটিফিকেশনের Reply অপশন
            try {
                val ri = action.remoteInputs[0]
                val i = Intent()
                val b = Bundle()
                b.putCharSequence(ri.resultKey, reply)
                RemoteInput.addResultsToIntent(action.remoteInputs, i, b)
                action.actionIntent.send(this, 0, i)
                sent = true
            } catch (_: Exception) {}
        } else {
            // পদ্ধতি ২: চ্যাট খুলে Accessibility দিয়ে টাইপ
            try {
                AutoTypeService.pending = Pending(reply, System.currentTimeMillis())
                n.contentIntent?.send()
                sent = n.contentIntent != null
            } catch (_: Exception) {}
        }
        Store.addChat(this, Chat(title, text, if (sent) reply else "", System.currentTimeMillis()))
    }
}
