package com.autoreply.pilot

import android.content.Context

object ReplyEngine {
    fun reply(c: Context, text: String): String {
        val l = text.lowercase()
        val prods = Store.products(c).lines().map { it.split("|") }
            .filter { it.size >= 2 && it[0].isNotBlank() }

        fun fmt(p: List<String>) = p[0].trim() + ": " + p[1].trim() + " টাকা" +
            (if (p.size > 2 && p[2].isNotBlank()) " (" + p[2].trim() + ")" else "")

        val hit = prods.filter { l.contains(it[0].trim().lowercase()) }
        if (hit.isNotEmpty())
            return hit.joinToString("। ") { fmt(it) } +
                "। অর্ডার করতে আপনার নাম, ফোন নম্বর ও ঠিকানা পাঠান।"

        if (prods.isNotEmpty() &&
            Regex("দাম|প্রাইস|কত টাকা|price|লিস্ট|list", RegexOption.IGNORE_CASE).containsMatchIn(text)
        ) return "আমাদের প্রোডাক্ট ও দাম: " + prods.joinToString("। ") { fmt(it) } + "।"

        var def = ""
        for (line in Store.rules(c).lines()) {
            val i = line.indexOf("=>")
            if (i < 0) continue
            val k = line.substring(0, i).trim()
            val r = line.substring(i + 2).trim()
            if (k == "*") { def = r; continue }
            if (k.split(",").any { it.isNotBlank() && l.contains(it.trim().lowercase()) }) return r
        }
        return def
    }
}
