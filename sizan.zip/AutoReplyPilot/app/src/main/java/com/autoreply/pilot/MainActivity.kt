package com.autoreply.pilot

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var chatBox: LinearLayout
    private val GREY = 0xFF8EA39A.toInt()
    private val CARD = 0xFF121D19.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, sz: Float = 15f, c: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
    private fun btn(t: String, f: () -> Unit) =
        Button(this).apply { text = t; setOnClickListener { f() } }
    private fun edit(t: String, lines: Int) = EditText(this).apply {
        setText(t); setTextColor(Color.WHITE); textSize = 14f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        minLines = lines; gravity = Gravity.TOP
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this)
        sv.setBackgroundColor(0xFF0B1512.toInt())
        sv.fitsSystemWindows = true
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(40))
        }
        sv.addView(root)
        setContentView(sv)

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("অটো রিপ্লাই পাইলট", 22f).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(Switch(this).apply {
            isChecked = Store.active(this@MainActivity)
            setOnCheckedChangeListener { _, v -> Store.setActive(this@MainActivity, v) }
        })
        root.addView(head)

        status = tv("", 14f, GREY)
        root.addView(status)
        root.addView(btn("১. নোটিফিকেশন অ্যাক্সেস চালু করুন") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        root.addView(btn("২. অ্যাক্সেসিবিলিটি চালু করুন (ব্যাকআপ, ঐচ্ছিক)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(tv("\nপ্রোডাক্ট (প্রতি লাইনে: নাম|দাম|বিবরণ)", 15f, GREY))
        val prodEt = edit(Store.products(this), 3); root.addView(prodEt)
        root.addView(tv("\nকীওয়ার্ড রুল (প্রতি লাইনে: কীওয়ার্ড১,কীওয়ার্ড২=>উত্তর, ডিফল্ট: *=>উত্তর)", 15f, GREY))
        val ruleEt = edit(Store.rules(this), 6); root.addView(ruleEt)
        root.addView(btn("সংরক্ষণ করুন") {
            Store.setProducts(this, prodEt.text.toString())
            Store.setRules(this, ruleEt.text.toString())
            Toast.makeText(this, "সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
        })

        root.addView(tv("\nটেস্ট", 15f, GREY))
        val testEt = edit("", 1).apply { hint = "কাস্টমারের মেসেজ লিখুন" }
        val testOut = tv("", 14f, 0xFF5FDCAB.toInt())
        root.addView(testEt)
        root.addView(btn("উত্তর দেখুন") {
            Store.setProducts(this, prodEt.text.toString())
            Store.setRules(this, ruleEt.text.toString())
            testOut.text = ReplyEngine.reply(this, testEt.text.toString())
        })
        root.addView(testOut)

        val ch = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        ch.addView(tv("\nচ্যাট লগ", 18f).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        ch.addView(btn("মুছুন") { Store.clearChats(this); refresh() })
        root.addView(ch)
        chatBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(chatBox)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun listenerOn() =
        (Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: "")
            .contains(packageName)

    private fun refresh() {
        status.text = if (listenerOn()) "● নোটিফিকেশন অ্যাক্সেস চালু আছে"
        else "● নোটিফিকেশন অ্যাক্সেস বন্ধ — নিচের ১ নম্বর বাটনে চাপুন"
        chatBox.removeAllViews()
        val fmt = SimpleDateFormat("MMM dd, hh:mm a", Locale.US)
        val blocked = Store.blocked(this)
        val chats = Store.chats(this)
        if (chats.isEmpty()) chatBox.addView(tv("এখনো কোনো চ্যাট নেই।", 14f, GREY))
        for (c in chats) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(CARD)
                setPadding(dp(12), dp(12), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(10) }
            }
            card.addView(tv(c.name + "  •  " + fmt.format(Date(c.time)), 15f))
            card.addView(tv("In: " + c.inMsg, 14f))
            card.addView(tv(if (c.outMsg.isNotEmpty()) "Out: " + c.outMsg else "Out: (পাঠানো যায়নি)", 14f, 0xFF5FDCAB.toInt()))
            card.addView(Switch(this).apply {
                text = "AI reply (এই চ্যাটে)"; setTextColor(GREY)
                isChecked = c.name !in blocked
                setOnCheckedChangeListener { _, _ -> Store.toggleBlocked(this@MainActivity, c.name) }
            })
            chatBox.addView(card)
        }
    }
}
